README
Homework #1
	A star algorithm homework

TEAM MEMBERS
Chris Nguyen - 007405892
Shunt Balushian - 007111208


